// Fill out your copyright notice in the Description page of Project Settings.
#include "MyPlayerController.h"
#include "Components/InputComponent.h"
#include "Kismet/GameplayStatics.h"
#include "SimplePawn.h"

DEFINE_LOG_CATEGORY_STATIC(LogMyPlayerController, All, All)

void AMyPlayerController::SetupInputComponent()
{
	Super::SetupInputComponent();

	//TODO: Bind the button press action to switch pawns. Can the pawns input bindings be moved here?
	if (InputComponent)
	{
		//BIND Action "ChangePawn", On the key Event Pressed to this object's ChangePawn() Function
		InputComponent->BindAction("ChangePawn", IE_Pressed, this, &AMyPlayerController::ChangePawn);
	}
}

void AMyPlayerController::BeginPlay()
{
	Super::BeginPlay();

	//TODO: Get all actors of type ASimplePawn that are in the level
	TArray<AActor*> FoundPawns;
	UGameplayStatics::GetAllActorsOfClass(GetWorld(), ASimplePawn::StaticClass(), FoundPawns);

	//Copy found pawns to Pawns array
	Pawns.Empty();
	Pawns.Append(FoundPawns);
}

void AMyPlayerController::ChangePawn()
{
	//TODO: Implement the logic to switch pawns in the Pawns TArray
	if (Pawns.Num() < 1)
	{
		return;
	}

	//Get the CurrentPawn from the Array of Pawns at CurrentPawnIndex.
	ASimplePawn* CurrentPawn = Cast<ASimplePawn>(Pawns[CurrentPawnIndex]);

	//Set the CurrentPawnIndex to the Next Pawn in the Pawns array.
	CurrentPawnIndex = (CurrentPawnIndex + 1) % Pawns.Num();

	//If the CurrentPawn is null, return.
	if (!CurrentPawn)
	{
		return;
	}

	//Possess the CurrentPawn.
	Possess(CurrentPawn);

	UE_LOG(LogMyPlayerController, Warning, TEXT("Change Pawn"));
}
