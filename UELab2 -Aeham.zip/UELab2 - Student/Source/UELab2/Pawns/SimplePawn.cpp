// Fill out your copyright notice in the Description page of Project Settings.


#include "SimplePawn.h"
#include "Components/InputComponent.h"
#include "Camera/CameraComponent.h"
#include "Components/StaticMeshComponent.h"
#include "GameFramework/SpringArmComponent.h"

DEFINE_LOG_CATEGORY_STATIC(LogSimplePawn, All, All)

// Sets default values
ASimplePawn::ASimplePawn()
{
	PrimaryActorTick.bCanEverTick = true;

	//TODO: Create the component hierarchy for this actor. What does the hierarchy look like? Draw it out on paper.
	SceneComponent = CreateDefaultSubobject<USceneComponent>(TEXT("SceneComponent"));
	SetRootComponent(SceneComponent);

	MeshSceneComponent = CreateDefaultSubobject<USceneComponent>(TEXT("MeshSceneComponent"));
	MeshSceneComponent->SetupAttachment(SceneComponent);

	StaticMeshComponent = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("StaticMeshComponent"));
	StaticMeshComponent->SetupAttachment(MeshSceneComponent);

	SpringArmComponent = CreateDefaultSubobject<USpringArmComponent>(TEXT("SpringArmComponent"));
	SpringArmComponent->SetupAttachment(SceneComponent);
	SpringArmComponent->bUsePawnControlRotation = true;

	CameraComponent = CreateDefaultSubobject<UCameraComponent>(TEXT("CameraComponent"));
	CameraComponent->SetupAttachment(SpringArmComponent);
}

void ASimplePawn::BeginPlay()
{
	Super::BeginPlay();
}

void ASimplePawn::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

	//TODO: Implement the movement logic
	if (Controller)
	{
		FRotator Rotation(0.f, Controller->GetControlRotation().Yaw, 0.f);
		FVector Direction = FVector::ZeroVector;

		if (MoveForwardAmount != 0.f)
		{
			Direction += FRotationMatrix(Rotation).GetUnitAxis(EAxis::X);
			FVector NewLocation = GetActorLocation() + Direction * MoveForwardAmount * Velocity * DeltaTime;
			SetActorLocation(NewLocation);
		}

		if (MoveRightAmount != 0.f)
		{
			Direction += FRotationMatrix(Rotation).GetUnitAxis(EAxis::Y);
			FVector NewLocation = GetActorLocation() + Direction * MoveRightAmount * Velocity * DeltaTime;
			SetActorLocation(NewLocation);
		}
	}
}

void ASimplePawn::SetupPlayerInputComponent(UInputComponent * PlayerInputComponent)
{
	Super::SetupPlayerInputComponent(PlayerInputComponent);

	//TODO: Set up the Input Bindings. Be mindful of each input binding. What is the difference between the movement and looking around
	if (PlayerInputComponent)
	{
		PlayerInputComponent->BindAxis("MoveForward", this, &ASimplePawn::MoveForward);
		PlayerInputComponent->BindAxis("MoveRight", this, &ASimplePawn::MoveRight);
		PlayerInputComponent->BindAxis("LookUp", this, &APawn::AddControllerPitchInput);
		PlayerInputComponent->BindAxis("LookRight", this, &APawn::AddControllerYawInput);
	}
}

void ASimplePawn::MoveForward(float Amount)
{
	//TODO: Set the MoveForwardAmount, what are the values passed in?
	MoveForwardAmount = Amount;
}

void ASimplePawn::MoveRight(float Amount)
{
	//TODO: Set the MoveRightAmount, what are the values passed in?
	MoveRightAmount = Amount;
}
void ASimplePawn::PossessedBy(AController* NewController)
{
	Super::PossessedBy(NewController);

	if (!NewController) 
		return;
	UE_LOG(LogSimplePawn, Warning, TEXT("%s PossessBy: %s"), *GetName(), *NewController->GetName());
}

void ASimplePawn::UnPossessed()
{
	Super::UnPossessed();
	UE_LOG(LogSimplePawn, Warning, TEXT("%s Un Prossessed"), *GetName());
}

