#include "Pawns/CustomMovementPawn.h"
#include "CustomMovementComponent.h"
#include "GameFramework/SpringArmComponent.h"

ACustomMovementPawn::ACustomMovementPawn()
{
	// Add the Simple Movement Component to this Pawn
	SimpleMovementComponent = CreateDefaultSubobject<UCustomMovementComponent>(TEXT("Simple Movement Component"));

	// Assign the RootComponent to the SimpleMovementComponent's UpdatedComponent variable
	SetRootComponent(Cast<USceneComponent>(SimpleMovementComponent));


}

void ACustomMovementPawn::SetupPlayerInputComponent(UInputComponent* PlayerInputComponent)
{
	Super::SetupPlayerInputComponent(PlayerInputComponent);
}

void ACustomMovementPawn::MoveForward(float Amount)
{
	if (!Controller)
		return;

	// Get the Rotation from the Controller and assign it to a FRotator called Rotation
	FRotator Rotation = Controller->GetControlRotation();

	// Declare a FRotator called YawRotation and initialize its pitch=0, roll=0 and the yaw=the controller rotation's yaw
	FRotator YawRotation(0.f, Rotation.Yaw, 0.f);

	// Declare a FVector Direction and assign it to FRotationMatrix(YawRotation).GetUnitAxis(EAxis::X)
	FVector Direction = FRotationMatrix(YawRotation).GetUnitAxis(EAxis::X);

	// Apply the forward and back movement
	if (SimpleMovementComponent)
	{
		SimpleMovementComponent->AddInputVector(Direction * Amount);
	}
}

void ACustomMovementPawn::MoveRight(float Amount)
{
	if (!Controller)
		return;

	// Get the Rotation from the Controller and assign it to a FRotator called Rotation
	FRotator Rotation = Controller->GetControlRotation();

	// Declare a FRotator called YawRotation and initialize its pitch=0, roll=0 and the yaw=the controller rotation's yaw
	FRotator YawRotation(0.f, Rotation.Yaw, 0.f);

	// Declare a FVector Direction and assign it to FRotationMatrix(YawRotation).GetUnitAxis(EAxis::Y)
	FVector Direction = FRotationMatrix(YawRotation).GetUnitAxis(EAxis::Y);

	// Apply the right and left movement
	if (SimpleMovementComponent)
	{
		SimpleMovementComponent->AddInputVector(Direction * Amount);
	}
}
